package com.sam.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sam.assistant.ui.SamState
import com.sam.assistant.service.SamService
import com.sam.assistant.ui.SamViewModel
import com.sam.assistant.ui.StatusPanel
import com.sam.assistant.ui.SettingsPanel

class MainActivity : ComponentActivity() {
    private val vm: SamViewModel by viewModels()
    private var autoListen by mutableStateOf(false)
    private var tick by mutableStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)   // lets SAM appear over the lock screen (does NOT unlock)
        autoListen = intent?.getBooleanExtra("listen", false) == true
        setContent { MaterialTheme(colorScheme = darkColorScheme()) {
            SamScreen(vm, autoListen, { autoListen = false }, tick) } }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("listen", false)) autoListen = true
    }
    override fun onResume() { super.onResume(); tick++ }
}

@Composable
fun SamScreen(vm: SamViewModel, autoListen: Boolean, onAutoConsumed: () -> Unit, tick: Int) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.listen() else vm.permissionDenied()
    }
    val toolPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.retry() else vm.permissionDenied("Sir, permission ke bina ye kaam nahi ho sakta.")
    }
    LaunchedEffect(vm.permRequest) { vm.permRequest?.let { p -> vm.clearPerm(); toolPerm.launch(p) } }
    fun mic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.listen()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> u?.let { vm.attach(it) } }
    var input by remember { mutableStateOf("") }
    var showStatus by remember { mutableStateOf(false) }
    var svcOn by remember { mutableStateOf(SamService.running) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        SamService.start(ctx); svcOn = true
    }
    LaunchedEffect(autoListen) { if (autoListen) { onAutoConsumed(); mic() } }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05070F), Color(0xFF0B1330))))
        .systemBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("SAM", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 8.sp)
        TextButton({ showStatus = !showStatus }) { Text(vm.state.name + "  •  Status ▾", fontSize = 12.sp, color = Color(0xFF6FA8FF)) }
        if (showStatus) StatusPanel(ctx, tick, svcOn) { on ->
            if (on) {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                else { SamService.start(ctx); svcOn = true }
            } else { SamService.stop(ctx); svcOn = false }
        }
        if (showStatus) SettingsPanel(vm.prefs)
        Spacer(Modifier.height(12.dp))
        Orb(vm.state)
        Spacer(Modifier.height(12.dp))
        val locked = remember(tick) { (ctx.getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked }
        val visible = if (locked) vm.messages.takeLast(1) else vm.messages.toList() // privacy: no history on lock screen
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(visible) { m ->
                Box(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, modifier = Modifier.clip(RoundedCornerShape(16.dp))
                        .background(if (m.fromUser) Color(0xFF2A4BFF) else Color(0xFF1A2342)).padding(12.dp))
                }
            }
        }
        vm.attachment?.let { a ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📎 " + a.name, Modifier.weight(1f), color = Color(0xFF7CFFB2), fontSize = 12.sp)
                TextButton({ vm.dropAttachment() }) { Text("✕") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ picker.launch("*/*") }) { Text("📎") }
            OutlinedTextField(input, { input = it }, Modifier.weight(1f),
                placeholder = { Text("Sam se kuch kahein…") }, singleLine = true)
            TextButton({ if (input.isNotBlank()) { vm.submit(input); input = "" } }) { Text("Send") }
            FilledIconButton({ mic() }, Modifier.size(52.dp)) { Text("🎙") }
        }
    }
}

@Composable
fun Orb(state: SamState) {
    val t = rememberInfiniteTransition(label = "orb")
    val speed = when (state) { SamState.LISTENING -> 500; SamState.THINKING, SamState.EXECUTING -> 900; SamState.SPEAKING -> 350; else -> 2200 }
    val s by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(speed, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val c = if (state == SamState.ERROR) Color(0xFFFF4D4D) else Color(0xFF4D7CFF)
    Box(Modifier.size(120.dp).scale(s).clip(CircleShape)
        .background(Brush.radialGradient(listOf(Color.White.copy(0.9f), c, Color(0xFF0B1330)))))
}
