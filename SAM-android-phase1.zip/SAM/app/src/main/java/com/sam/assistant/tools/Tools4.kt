package com.sam.assistant.tools

import com.sam.assistant.ai.GeminiClient
import com.sam.assistant.core.*
import com.sam.assistant.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class RememberTool(private val p: Prefs) : Tool {
    override val name = "remember"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        if (!p.memoryOn) return ToolResult(Status.FAILED, "Memory band hai, settings mein on karein")
        val f = args["fact"]?.takeIf { it.isNotBlank() } ?: return ToolResult(Status.FAILED, "Kya yaad rakhoon?")
        p.addMemory(f); return ToolResult(Status.SUCCESS, "Yaad rakh liya: $f")
    }
}

class CreateRoutineTool(private val p: Prefs) : Tool {
    override val name = "create_routine"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val n = args["name"]?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: return ToolResult(Status.FAILED, "Routine ka naam?")
        val steps = try { JSONArray(args["steps"] ?: "") } catch (e: Exception) { return ToolResult(Status.FAILED, "Routine ke steps samajh nahi aaye") }
        if (steps.length() == 0) return ToolResult(Status.FAILED, "Routine mein koi step nahi hai")
        p.saveRoutine(n, steps.toString())
        return ToolResult(Status.SUCCESS, "'$n' routine save ho gaya, ab bas '$n' bol dein")
    }
}

class RunRoutineTool(private val p: Prefs, private val runner: suspend (ToolCall) -> ToolResult) : Tool {
    override val name = "run_routine"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val n = args["name"]?.trim()?.lowercase() ?: return ToolResult(Status.FAILED, "Kaunsa routine?")
        val steps = JSONArray(p.routines()[n] ?: return ToolResult(Status.FAILED, "'$n' naam ka routine nahi mila"))
        val lines = mutableListOf<String>(); var allOk = true
        for (i in 0 until steps.length()) {
            val o = steps.getJSONObject(i); val tool = o.optString("tool")
            if (tool == "run_routine") continue
            val a = o.optJSONObject("args") ?: JSONObject()
            val r = runner(ToolCall(tool, a.keys().asSequence().associateWith { a.opt(it).toString() }))
            if (r.status != Status.SUCCESS) allOk = false
            lines += (if (r.status == Status.SUCCESS) "✓ " else "✗ ") + r.message
        }
        return ToolResult(if (allOk) Status.SUCCESS else Status.FAILED, lines.joinToString("\n"))
    }
}

/** Separate Gemini call with Google Search grounding, so answers about current facts come from the web. */
class WebAnswerTool(private val p: Prefs, private val client: GeminiClient) : Tool {
    override val name = "search_web_answer"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        if (p.apiKey.isBlank()) return ToolResult(Status.FAILED, "Gemini API key set nahi hai")
        val q = args["query"] ?: return ToolResult(Status.FAILED, "Kya search karoon?")
        return withContext(Dispatchers.IO) {
            try {
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts",
                    JSONArray().put(JSONObject().put("text", "Answer briefly with current, verified facts: $q")))))
                    .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                val parts = client.generate(body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val t = (0 until (parts?.length() ?: 0)).joinToString(" ") { parts!!.getJSONObject(it).optString("text") }.trim()
                if (t.isBlank()) ToolResult(Status.FAILED, "Web se jawab nahi mila") else ToolResult(Status.SUCCESS, t)
            } catch (e: IOException) { ToolResult(Status.NETWORK_ERROR, "Internet ya Gemini response nahi aaya") }
        }
    }
}
