package com.sam.assistant.tools

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import com.sam.assistant.core.*
import java.text.SimpleDateFormat
import java.util.*

internal fun Context.launch(i: Intent): Boolean {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { startActivity(i); true } catch (e: android.content.ActivityNotFoundException) { false }
}

class OpenAppTool(private val c: Context) : Tool {
    override val name = "open_app"
    override val requiresUnlock = true
    private val aliases = mapOf("youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome", "maps" to "com.google.android.apps.maps")
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val q = args["app"]?.lowercase()?.trim() ?: return ToolResult(Status.FAILED, "Kaunsa app?")
        val pm = c.packageManager
        val pkg = aliases[q]?.takeIf { pm.getLaunchIntentForPackage(it) != null } ?: run {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(main, 0).firstOrNull {
                it.loadLabel(pm).toString().lowercase().contains(q)
            }?.activityInfo?.packageName
        } ?: return ToolResult(Status.APP_NOT_INSTALLED, "$q app mujhe mila nahi")
        val i = pm.getLaunchIntentForPackage(pkg) ?: return ToolResult(Status.FAILED, "$q open nahi ho paya")
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "$q open hai") else ToolResult(Status.FAILED, "$q open nahi ho paya")
    }
}

class SetTimerTool(private val c: Context) : Tool {
    override val name = "set_timer"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val s = args["seconds"]?.toIntOrNull() ?: return ToolResult(Status.FAILED, "Kitne minute ka timer?")
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "${s / 60} minute ka timer chal raha hai")
        else ToolResult(Status.NOT_SUPPORTED, "Clock app timer request accept nahi kar raha")
    }
}

class SetAlarmTool(private val c: Context) : Tool {
    override val name = "set_alarm"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val h = args["hour"]?.toIntOrNull(); val m = args["minute"]?.toIntOrNull() ?: 0
        if (h == null) return ToolResult(Status.FAILED, "Kitne baje ka alarm?")
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .also { x -> args["message"]?.let { x.putExtra(AlarmClock.EXTRA_MESSAGE, it) } }
        return if (c.launch(i)) ToolResult(Status.SUCCESS, if (args["message"] != null) "%d:%02d par reminder set hai: %s".format(h, m, args["message"]) else "%d:%02d ka alarm set hai".format(h, m))
        else ToolResult(Status.NOT_SUPPORTED, "Clock app alarm request accept nahi kar raha")
    }
}

class BatteryTool(private val c: Context) : Tool {
    override val name = "get_battery_status"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val chg = if (bm.isCharging) ", charging chal rahi hai" else ""
        return ToolResult(Status.SUCCESS, "Battery $pct% hai$chg")
    }
}

class TimeTool : Tool {
    override val name = "get_time"
    override suspend fun execute(args: Map<String, String>) =
        ToolResult(Status.SUCCESS, SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + " baje hain")
}

class DeviceInfoTool : Tool {
    override val name = "get_device_info"
    override suspend fun execute(args: Map<String, String>) =
        ToolResult(Status.SUCCESS, "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
}

class OpenSettingsTool(private val c: Context) : Tool {
    override val name = "open_settings"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val action = when (args["section"]) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (c.launch(Intent(action))) ToolResult(Status.SUCCESS, "${args["section"] ?: "Settings"} settings khul gayi")
        else ToolResult(Status.FAILED, "Settings open nahi ho payi")
    }
}

class WebSearchTool(private val c: Context) : Tool {
    override val name = "search_web"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val q = args["query"] ?: return ToolResult(Status.FAILED, "Kya search karoon?")
        val ok = c.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return if (ok) ToolResult(Status.SUCCESS, "'$q' browser mein search ke liye khol diya")
        else ToolResult(Status.FAILED, "Browser open nahi hua")
    }
}

private fun Context.openSettings(action: String, withPkg: Boolean = false) {
    val i = Intent(action); if (withPkg) i.data = Uri.parse("package:$packageName"); launch(i)
}

class VolumeTool(private val c: Context) : Tool {
    override val name = "control_volume"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val (stream, label) = when (args["type"]) {
            "alarm" -> AudioManager.STREAM_ALARM to "alarm"
            "ring" -> AudioManager.STREAM_RING to "ring"
            "notification" -> AudioManager.STREAM_NOTIFICATION to "notification"
            else -> AudioManager.STREAM_MUSIC to "media"
        }
        val max = am.getStreamMaxVolume(stream); val cur = am.getStreamVolume(stream)
        val step = maxOf(1, max / 10)
        val target = (args["level"]?.toIntOrNull()?.let { Math.round(it.coerceIn(0, 100) * max / 100f) }
            ?: (cur + (args["delta"]?.toIntOrNull() ?: 0) * step)).coerceIn(0, max)
        try { am.setStreamVolume(stream, target, 0) }
        catch (e: SecurityException) {
            c.openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return ToolResult(Status.PERMISSION_REQUIRED, "$label volume ke liye Do Not Disturb access chahiye, settings khol di hain")
        }
        val pct = am.getStreamVolume(stream) * 100 / max
        return if (am.getStreamVolume(stream) == target) ToolResult(Status.SUCCESS, "$label volume $pct% hai")
        else ToolResult(Status.FAILED, "$label volume badal nahi paya (abhi $pct%)")
    }
}

class BrightnessTool(private val c: Context) : Tool {
    override val name = "set_brightness"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        if (!Settings.System.canWrite(c)) {
            c.openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, true)
            return ToolResult(Status.PERMISSION_REQUIRED, "Brightness ke liye 'Modify system settings' allow karna hoga, settings khol di hain")
        }
        val cr = c.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val target = (args["level"]?.toIntOrNull()?.let { it.coerceIn(1, 100) * 255 / 100 }
            ?: (cur + (args["delta"]?.toIntOrNull() ?: 0) * 25)).coerceIn(1, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target)
        val now = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1)
        return if (now == target) ToolResult(Status.SUCCESS, "Brightness ${now * 100 / 255}% hai")
        else ToolResult(Status.FAILED, "Brightness badal nahi paya")
    }
}

class DndTool(private val c: Context) : Tool {
    override val name = "set_dnd"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            c.openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return ToolResult(Status.PERMISSION_REQUIRED, "Do Not Disturb access allow karna hoga, settings khol di hain")
        }
        val on = args["state"] != "off"
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        val isOn = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        return if (isOn == on) ToolResult(Status.SUCCESS, if (on) "Do Not Disturb on hai" else "Do Not Disturb off hai")
        else ToolResult(Status.FAILED, "Do Not Disturb badal nahi paya")
    }
}

/** Wi-Fi: direct toggle only on Android 9 and below; Android 10+ gets the system Wi-Fi panel. Bluetooth: settings only. */
class ConnectivityTool(private val c: Context) : Tool {
    override val name = "toggle_connectivity"
    override val requiresUnlock = true
    @Suppress("DEPRECATION")
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val on = args["state"] != "off"
        if (args["what"] == "bluetooth") {
            c.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
            return ToolResult(Status.ANDROID_RESTRICTION, "Bluetooth direct on/off Android allow nahi karta, Bluetooth settings khol di hain")
        }
        if (Build.VERSION.SDK_INT >= 29) {
            c.openSettings(Settings.Panel.ACTION_WIFI)
            return ToolResult(Status.ANDROID_RESTRICTION, "Wi-Fi direct on/off Android 10+ par allowed nahi, Wi-Fi panel khol diya hai, wahan se toggle karein")
        }
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.isWifiEnabled = on
        val now = wm.isWifiEnabled
        return if (now == on) ToolResult(Status.SUCCESS, if (on) "Wi-Fi on hai" else "Wi-Fi off hai")
        else ToolResult(Status.FAILED, "Wi-Fi badal nahi paya")
    }
}
