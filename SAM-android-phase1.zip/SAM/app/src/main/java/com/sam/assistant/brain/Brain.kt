package com.sam.assistant.brain

import com.sam.assistant.core.*

data class Plan(val calls: List<ToolCall>, val directReply: String? = null, val english: Boolean = false)

/** Swap this for an LLM adapter (via your secure backend) without touching UI or tools. */
interface Brain {
    fun plan(text: String): Plan
    fun summarize(plan: Plan, results: List<Pair<ToolCall, ToolResult>>): String
}

/** Offline Hinglish/English rule-based planner. Handles multi-step commands. */
class RuleBasedBrain : Brain {
    private val english = Regex("^(what|how|open|set|turn|tell|battery|time|call|search|start)\\b")

    override fun plan(text: String): Plan {
        val t = text.lowercase().replace(Regex("^(hey )?sam[, ]*"), "").trim()
        val eng = english.containsMatchIn(t) && !t.contains("karo") && !t.contains("kholo")
        if (t.isBlank()) return Plan(emptyList(), if (eng) "Yes Sir?" else "Ji Sir?", eng)
        val segs = if (Regex("(message|sms|msg).*(\\bki\\b|that)").containsMatchIn(t)) listOf(t)
            else t.split(Regex("\\s*(,|\\baur\\b|\\bphir\\b|\\band then\\b|\\band\\b)\\s*"))
        val calls = segs
            .filter { it.isNotBlank() }.flatMap { parse(it.trim()) }
        if (calls.isEmpty()) return Plan(emptyList(),
            if (eng) "Sir, I can't do that yet. Needs the AI model connected." else
            "Sir, ye main abhi samajh nahi paya. Is type ki baat ke liye AI model connect karna hoga.", eng)
        return Plan(calls, null, eng)
    }

    private var lastWeatherCity: String? = null
    private var lastWasWeather = false

    private fun parseTime(s: String): Pair<Int, Int>? {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(baje|bje|am|pm)|(\\d{1,2}):(\\d{2})").find(s) ?: return null
        var h = (m.groups[1]?.value ?: m.groups[4]?.value)!!.toInt()
        val min = (m.groups[2]?.value ?: m.groups[5]?.value ?: "0").toInt()
        if (h < 12 && Regex("shaam|raat|dopahar|evening|night|afternoon|\\bpm\\b").containsMatchIn(s)) h += 12
        return h to min
    }
    private fun dayOffset(s: String) = if (Regex("\\bkal\\b|tomorrow").containsMatchIn(s)) 1 else 0

    /** Phase 3: weather, city, reminders, calendar, SMS draft, calls. Returns true if it handled the segment. */
    private fun phase3(s: String, out: MutableList<ToolCall>): Boolean {
        val prevWeather = lastWasWeather; lastWasWeather = false
        Regex("(?:mera shehar|my city is)\\s+(.+?)(?:\\s+hai)?$").find(s)?.let {
            out += ToolCall("set_city", mapOf("city" to it.groupValues[1])); return true }
        if (prevWeather && Regex("^(kal|tomorrow|aaj|today)\\??$").matches(s.trim())) {
            lastWasWeather = true
            out += ToolCall("get_weather", buildMap { put("day", "${dayOffset(s)}"); lastWeatherCity?.let { put("city", it) } }); return true
        }
        if (Regex("weather|mausam|baarish|barish|temperature").containsMatchIn(s)) {
            val city = s.replace(Regex("\\b(weather|mausam|ka|ki|ke|batao|bata|do|kaisa|hai|aaj|kal|today|tomorrow|in|mein|me|baarish|barish|hogi|kya|temperature|check|karo|what|is|the|how)\\b"), "")
                .replace(Regex("\\s+"), " ").trim().ifBlank { null } ?: lastWeatherCity
            lastWeatherCity = city; lastWasWeather = true
            out += ToolCall("get_weather", buildMap { put("day", "${dayOffset(s)}"); city?.let { put("city", it) } }); return true
        }
        if (Regex("reminder|yaad dila").containsMatchIn(s)) {
            val t = parseTime(s)
            val text = s.replace(Regex("\\b(kal|aaj|subah|shaam|raat|reminder|bana|do|karo|yaad|dilana|dila|ka|ki|set|me|mujhe)\\b|\\d{1,2}(:\\d{2})?\\s*(baje|bje|am|pm)?"), "")
                .replace(Regex("\\s+"), " ").trim().ifBlank { "Reminder" }
            out += ToolCall("set_alarm", if (t != null) mapOf("hour" to "${t.first}", "minute" to "${t.second}", "message" to text) else emptyMap()); return true
        }
        if (Regex("schedule|calendar|events?|meeting|agenda").containsMatchIn(s)) {
            val t = parseTime(s)
            if (t != null && Regex("bana|add|create").containsMatchIn(s)) {
                val title = s.replace(Regex("\\b(kal|aaj|bana|add|create|do|karo|calendar|mein|me|event|ka|ki)\\b|\\d{1,2}(:\\d{2})?\\s*(baje|bje|am|pm)?"), "")
                    .replace(Regex("\\s+"), " ").trim().ifBlank { "Event" }
                out += ToolCall("create_calendar_event", mapOf("title" to title, "hour" to "${t.first}", "minute" to "${t.second}", "day" to "${dayOffset(s)}"))
            } else out += ToolCall("get_calendar_events", mapOf("day" to "${dayOffset(s)}"))
            return true
        }
        if (Regex("\\b(message|sms|msg)\\b").containsMatchIn(s)) {
            val m = Regex("^(.+?)\\s+ko\\s+(?:message|sms|msg)\\s*(?:bhejo|bhej do|karo|send|kar do)?\\s*(?:ki|ke liye|that)?\\s*(.*)$").find(s)
            out += ToolCall("send_message", if (m != null) mapOf("contact" to m.groupValues[1], "text" to m.groupValues[2]) else emptyMap()); return true
        }
        if (Regex("\\b(call|dial)\\b").containsMatchIn(s)) {
            val name = s.replace(Regex("\\b(call|dial|karo|ko|phone|laga|lagao|do|kar|please|to)\\b"), "").replace(Regex("\\s+"), " ").trim()
            out += ToolCall("make_call", when {
                name.isBlank() -> emptyMap()
                name.matches(Regex("[+\\d ]+")) -> mapOf("number" to name.replace(" ", ""))
                else -> mapOf("contact" to name) }); return true
        }
        return false
    }

    private fun parse(s: String): List<ToolCall> {
        val out = mutableListOf<ToolCall>()
        if (phase3(s, out)) {}
        else if (Regex("battery").containsMatchIn(s)) out += ToolCall("get_battery_status")
        else if (Regex("volume|awaaz|awaz").containsMatchIn(s)) {
            val type = when { s.contains("alarm") -> "alarm"; s.contains("ring") -> "ring"; s.contains("notification") -> "notification"; else -> "media" }
            val n = Regex("(\\d+)").find(s)?.value
            val a = mutableMapOf("type" to type)
            when {
                Regex("mute|silent|band").containsMatchIn(s) -> a["level"] = "0"
                n != null -> a["level"] = n
                Regex("kam|ghata|decrease|down|lower|low").containsMatchIn(s) -> a["delta"] = "-1"
                else -> a["delta"] = "1"
            }
            out += ToolCall("control_volume", a)
        } else if (Regex("brightness|roshni").containsMatchIn(s)) {
            val n = Regex("(\\d+)").find(s)?.value
            out += ToolCall("set_brightness", if (n != null) mapOf("level" to n)
                else mapOf("delta" to if (Regex("kam|ghata|decrease|down|lower|low").containsMatchIn(s)) "-1" else "1"))
        } else if (Regex("do not disturb|dnd|disturb").containsMatchIn(s)) {
            out += ToolCall("set_dnd", mapOf("state" to if (Regex("\\boff\\b|band|hata|disable|turn off").containsMatchIn(s)) "off" else "on"))
        } else if (Regex("kitne baje|time kya|what time|samay").containsMatchIn(s)) out += ToolCall("get_time")
        else if (Regex("device|phone model|android version").containsMatchIn(s)) out += ToolCall("get_device_info")
        else if (s.contains("timer")) {
            val n = Regex("(\\d+)").find(s)?.value?.toIntOrNull()
            val sec = when {
                n == null -> null
                Regex("second|sec").containsMatchIn(s) -> n
                Regex("hour|ghant").containsMatchIn(s) -> n * 3600
                else -> n * 60
            }
            out += ToolCall("set_timer", if (sec != null) mapOf("seconds" to "$sec") else emptyMap())
        } else if (s.contains("alarm")) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(s)
            var h = m?.groupValues?.get(1)?.toIntOrNull()
            if (h != null && h < 12 && Regex("shaam|raat|evening|night|\\bpm\\b").containsMatchIn(s)) h += 12
            val min = m?.groupValues?.get(2)?.ifBlank { "0" } ?: "0"
            out += ToolCall("set_alarm", if (h != null) mapOf("hour" to "$h", "minute" to min) else emptyMap())
        } else if (Regex("wi-?fi|bluetooth").containsMatchIn(s)) {
            val w = if (s.contains("bluetooth")) "bluetooth" else "wifi"
            out += if (s.contains("setting")) ToolCall("open_settings", mapOf("section" to w))
                   else ToolCall("toggle_connectivity", mapOf("what" to w,
                       "state" to if (Regex("\\boff\\b|band|disable").containsMatchIn(s)) "off" else "on"))
        } else if (s.contains("setting")) {
            val sec = when {
                s.contains("display") || s.contains("brightness") -> "display"
                s.contains("sound") || s.contains("volume") -> "sound"
                else -> "main"
            }
            out += ToolCall("open_settings", mapOf("section" to sec))
        } else if (Regex("search|dhundo|khojo").containsMatchIn(s)) {
            out += ToolCall("search_web", mapOf("query" to s.replace(Regex("\\b(search|karo|karna|dhundo|khojo|for|google)\\b"), "").trim()))
        } else if (Regex("kholo|khol do|open|start").containsMatchIn(s)) {
            val app = s.replace(Regex("\\b(kholo|khol|do|open|start|karo|app|please)\\b"), "").trim()
            if (app.isNotBlank()) out += ToolCall("open_app", mapOf("app" to app))
        }
        return out
    }

    override fun summarize(plan: Plan, results: List<Pair<ToolCall, ToolResult>>): String {
        val allOk = results.all { it.second.status == Status.SUCCESS }
        if (results.size == 1) return results[0].second.message + if (allOk) ", Sir." else "."
        val sb = StringBuilder(if (allOk) "Done Sir.\n" else "Sir, kuch kaam ho gaye, kuch nahi:\n")
        results.forEach { sb.append(if (it.second.status == Status.SUCCESS) "✓ " else "✗ ").append(it.second.message).append('\n') }
        return sb.toString().trim()
    }
}
