package com.sam.assistant.core

enum class Status { SUCCESS, FAILED, NOT_SUPPORTED, PERMISSION_REQUIRED, AUTHENTICATION_REQUIRED,
    USER_CONFIRMATION_REQUIRED, TIMEOUT, NETWORK_ERROR, APP_NOT_INSTALLED, ANDROID_RESTRICTION }

data class ToolResult(val status: Status, val message: String, val permission: String? = null)
data class ToolCall(val name: String, val args: Map<String, String> = emptyMap())

interface Tool {
    val name: String
    /** True = sensitive/protected action; refused while the phone is locked. */
    val requiresUnlock: Boolean get() = false
    suspend fun execute(args: Map<String, String>): ToolResult
}

/** Validation -> execution. The AI brain never touches Android; only tools do. */
class ToolRegistry(tools: List<Tool>, private val isLocked: () -> Boolean = { false }) {
    private val map = tools.associateBy { it.name }
    suspend fun run(call: ToolCall): ToolResult {
        val tool = map[call.name] ?: return ToolResult(Status.NOT_SUPPORTED, "Ye kaam abhi supported nahi hai")
        if (tool.requiresUnlock && isLocked())
            return ToolResult(Status.AUTHENTICATION_REQUIRED, "Is action ke liye phone unlock karna hoga")
        return try { tool.execute(call.args) }
        catch (e: SecurityException) { ToolResult(Status.PERMISSION_REQUIRED, "Is kaam ke liye permission chahiye") }
        catch (e: Exception) { ToolResult(Status.FAILED, "Ye nahi ho paya") }
    }
}
