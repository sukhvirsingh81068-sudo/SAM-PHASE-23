package com.sam.assistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local-only settings. The Gemini key is the user's own, typed into the app; it is never bundled in the APK. */
class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("sam", Context.MODE_PRIVATE)
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    var apiKey: String get() = s("apiKey", ""); set(v) { sp.edit().putString("apiKey", v).apply() }
    var model: String get() = s("model", "gemini-3.5-flash"); set(v) { sp.edit().putString("model", v).apply() }
    var lang: String get() = s("lang", "hi-IN"); set(v) { sp.edit().putString("lang", v).apply() }
    var memoryOn: Boolean get() = sp.getBoolean("memOn", true); set(v) { sp.edit().putBoolean("memOn", v).apply() }

    fun memories(): List<String> = JSONArray(s("mem", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addMemory(f: String) { sp.edit().putString("mem", JSONArray((memories() + f).takeLast(50)).toString()).apply() }
    fun clearMemories() { sp.edit().remove("mem").apply() }

    /** routine name (lowercase) -> JSON array of {"tool":..., "args":{...}} */
    fun routines(): Map<String, String> = JSONObject(s("routines", "{}")).let { o -> o.keys().asSequence().associateWith { o.getString(it) } }
    fun saveRoutine(name: String, steps: String) {
        val o = JSONObject(s("routines", "{}")); o.put(name.lowercase().trim(), steps)
        sp.edit().putString("routines", o.toString()).apply()
    }
    fun deleteRoutine(name: String) {
        val o = JSONObject(s("routines", "{}")); o.remove(name)
        sp.edit().putString("routines", o.toString()).apply()
    }
}
