package com.sam.assistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.sam.assistant.MainActivity

/** Foreground service: keeps SAM quickly reachable via a persistent notification. (Wake-word listening is NOT included yet.) */
class SamService : Service() {
    companion object {
        @Volatile var running = false
        fun start(c: Context) = c.startForegroundService(Intent(c, SamService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, SamService::class.java)) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("sam_bg", "SAM background", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).putExtra("listen", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, "sam_bg")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SAM ready hai")
            .setContentText("Tap karke SAM se baat karein").setContentIntent(open)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setOngoing(true)
            .addAction(0, "Talk to SAM", open).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        running = true
        return START_STICKY
    }
    override fun onDestroy() { running = false }
    override fun onBind(i: Intent?): IBinder? = null
}
